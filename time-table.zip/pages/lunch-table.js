import Layout from "../cmp/layout";
import LunchTable from "../cmp/lunch-table";
const LunchTableEl=()=>(<Layout> <LunchTable /></Layout>)
export default LunchTableEl;